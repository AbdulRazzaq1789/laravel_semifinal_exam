<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Student Course App')</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Noto+Naskh+Arabic:wght@400..700&family=Roboto:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    @stack('styles')
    <style>

    </style>
</head>

<body>

    <aside class="sidebar">
        <div class="sidebar-brand">
            <div class="brand-icon">A</div>
            <span>Acadmia</span>
        </div>
        <nav class="sidebar-nav">
            <div class="sidebar-section-label">Main</div>
            <a href="/" class="active">
                Dashboard
            </a>
            <a href="{{ route('students.index') }}">Students</a>
            <a href="{{ route('courses.index') }}">Courses</a>
            <a href="{{ route('enrollments.index') }}">Enrollments</a>

        </nav>
        <div class="sidebar-footer">
            <div class="avatar-sm">JD</div>
            <span>Dr. Jane Doe</span>
        </div>
    </aside>

    <!-- MAIN AREA -->
    <div class="main-area">
        <!-- NAVBAR -->
        <header class="navbar">
            <div class="navbar-left">
                <span class="page-title">@yield('title', 'Student Course App')</span>
            </div>
            <div class="navbar-right">
                @yield('actions')
            </div>
        </header>

        <!-- CONTENT -->
        <div class="content">
            {{-- Flash notifications --}}
            @if (session('success'))
                <div class="notification success">
                    {{ session('success') }}
                </div>
            @endif

            @if (session('info'))
                <div class="notification info">
                    {{ session('info') }}
                </div>
            @endif

            @if (session('warning'))
                <div class="notification warning">
                    {{ session('warning') }}
                </div>
            @endif

            @if (session('error'))
                <div class="notification error">
                    {{ session('error') }}
                </div>
            @endif
            @yield('content')

        </div>
    </div>
</body>

</html>
