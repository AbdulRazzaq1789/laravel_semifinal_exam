<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    protected $fillable = [
        'name',
        'code',
        'description'
    ];

    public function enrollments()
    {
        return $this->hasMany(Enrollment::class);
    }
}
